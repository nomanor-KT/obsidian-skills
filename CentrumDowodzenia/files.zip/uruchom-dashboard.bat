@echo off
title Centrum Dowodzenia — OSINT Dashboard
echo.
echo  ========================================
echo   CENTRUM DOWODZENIA — OSINT Dashboard
echo  ========================================
echo.
echo  Uruchamiam lokalny serwer...
echo  Dashboard otworzy sie w przegladarce.
echo  Nie zamykaj tego okna podczas pracy.
echo.
echo  Aby zakonczyc: nacisnij Ctrl+C lub zamknij okno.
echo  ========================================
echo.

cd /d "%~dp0"

REM Próbuj Python 3
where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [OK] Znaleziono Python. Uruchamiam serwer na porcie 8080...
    start "" "http://localhost:8080/centrum-dowodzenia.html"
    python -m http.server 8080
    goto :end
)

REM Próbuj Python jako py
where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [OK] Znaleziono Python (py). Uruchamiam serwer na porcie 8080...
    start "" "http://localhost:8080/centrum-dowodzenia.html"
    py -m http.server 8080
    goto :end
)

REM Próbuj npx (Node.js)
where npx >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [OK] Znaleziono Node.js. Uruchamiam serwer na porcie 8080...
    start "" "http://localhost:8080/centrum-dowodzenia.html"
    npx -y http-server -p 8080 -c-1
    goto :end
)

REM Brak serwera — otwórz bezpośrednio (ograniczona funkcjonalność)
echo [UWAGA] Nie znaleziono Python ani Node.js.
echo.
echo Otwieram plik bezposrednio w przegladarce.
echo Dla pelnej funkcjonalnosci zainstaluj Python:
echo   https://www.python.org/downloads/
echo.
start "" "%~dp0centrum-dowodzenia.html"

:end
